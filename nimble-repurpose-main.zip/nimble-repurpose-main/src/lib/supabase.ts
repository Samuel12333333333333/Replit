
// This file is being replaced by src/integrations/supabase/client.ts
// Importing from here for backward compatibility only
import { supabase } from '@/integrations/supabase/client';

export { supabase };
